---
name: Feature request
about: Suggest an idea for this project
title: ''
labels: ''
assignees: ''

---

**🧐 Motivation**
<!-- Is your feature request related to a specific problem? Is it just a crazy idea? Tell us about it! -->

**📝 Details**
<!-- Please describe your feature request in detail. -->

